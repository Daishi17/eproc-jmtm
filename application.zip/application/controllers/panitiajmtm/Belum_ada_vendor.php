<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Belum_ada_vendor extends CI_Controller
{


    public function index()
    {
        $this->load->view('panitia_view/belum_ada_vendor/index');
    }
}
